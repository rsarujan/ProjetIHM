import java.util.ArrayList;

public interface Donnees {
	public final static String[] couleurs = {"rouge","bleu","vert"};
	public final static String[] formes = {"cercle","carre"};
	public static ArrayList dessin = new ArrayList();
}
