import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanneauSud extends JPanel
{
	private Image img =  getToolkit().getImage("paint.png");
	
	public void paintComponent(Graphics g)
    {
		g.drawImage(img, 0, 0,null);
	}

}
