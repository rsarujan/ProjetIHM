import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Centre extends JPanel implements Donnees{
	public Centre() {
		this.setBackground(Color.WHITE); 
		
	}

	public void paintComponent(Graphics g){
		
		Donnees.dessin.toString();
		
		for(int i = 0; i<Donnees.dessin.size();i++) {
			Dessin a = (Dessin) Donnees.dessin.get(i);
			g.setColor(a.getCouleur());
			if(a.getForme() == "cercle") {
				g.fillOval(a.getX()-(a.getTaille()/2), a.getY()-100-(a.getTaille()/2), a.getTaille(), a.getTaille());
				/*a.setX(a.getX()-(a.getTaille()/2));
				a.setY(a.getY()-100-(a.getTaille()/2));*/
			}
			else if(a.getForme() == "carre") {
				g.fillRect(a.getX()-(a.getTaille()/2), a.getY()-100-(a.getTaille()/2), a.getTaille(), a.getTaille());
		
			}
				
		}
	}
}
