import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

@SuppressWarnings("serial")
public class Paint extends JFrame implements Donnees{

	private JComboBox couleur = new JComboBox();
	private JComboBox forme = new JComboBox();
	private JTextField taille = new JTextField(10);

	private JButton eff = new JButton("Effacer tout");
	private JButton rev = new JButton("Revenir en arrière");

	private JToggleButton crayon = new JToggleButton( new ImageIcon("pencil.png"));
	private JToggleButton gomme = new JToggleButton( new ImageIcon("rubber.png"));
	private JToggleButton dep = new JToggleButton( new ImageIcon("move2.png"));

	private PanneauSud panneau = new PanneauSud();
	private Centre center = new Centre();

	private int x;
	private int y;

	public Paint()
    {

		Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();

		this.setTitle("Paint");

		/*this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(0, 0,(int) dimension.getWidth() ,(int) dimension.getHeight()-100);*/

		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		//this.setAlwaysOnTop(true);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		Menu();
		//Nord();
		Center();
		Sud();
		Mouse();

		this.setVisible(true);
	}

	public static String choix_fichier()
    {
		String f = null;
		JFileChooser choix=new JFileChooser();
		int retour=choix.showOpenDialog(null);
		if(retour==JFileChooser.APPROVE_OPTION)
        {
			f = choix.getSelectedFile().getAbsolutePath();
        }
		else
			JOptionPane.showMessageDialog(null,"No file chose", "ERROR", JOptionPane.ERROR_MESSAGE);
		return f;
	}

	public void ouvrir_f() throws NumberFormatException, IOException
    {

		String mot = null;
		BufferedReader br=null;
		try
        {
			br = new BufferedReader(new FileReader(choix_fichier()));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

		if(br.readLine().equals("Paint"))
        {
			while((mot = br.readLine())!=null)
            {
				int taille = Integer.parseInt(mot);
				String forme = br.readLine();
				Color couleur = new Color(Integer.parseInt(br.readLine()),Integer.parseInt(br.readLine()),Integer.parseInt(br.readLine()));
				int x = Integer.parseInt(br.readLine());
				int y = Integer.parseInt(br.readLine());

				System.out.println("taille :"+ taille+" forme : "+ forme + " couleur:" + couleur+"  x : "+x+"  y: "+y);


				Dessin a = new Dessin(taille,  forme, couleur, x,y);
				System.out.println(a);
				Donnees.dessin.add(a);
                center.repaint();

			}
		}
		else
			System.out.println("nin");
		br.close();
        //System.out.println(Donnees.dessin);
	}

	public void sauvegarder_f() throws IOException
    {
		BufferedWriter bw = null;
		try
        {
			bw = new BufferedWriter(new FileWriter("Paint.txt"));
		} catch (IOException e)
        {
			e.printStackTrace();
		}

		bw.write("Paint");
		bw.newLine();


		for(int i=0; i< Donnees.dessin.size(); i++)
        {
			Dessin a = (Dessin) Donnees.dessin.get(i); 

			//System.out.println(a);
			bw.write(Integer.toString(a.getTaille()));
			bw.newLine();
			bw.write(a.getForme());
			bw.newLine();
			bw.write(Integer.toString(a.getCouleur().getRed()));
			bw.newLine();
			bw.write(Integer.toString(a.getCouleur().getGreen()));
			bw.newLine();
			bw.write(Integer.toString(a.getCouleur().getBlue()));
			bw.newLine();
			bw.write(Integer.toString(a.getX()));
			bw.newLine();
			bw.write(Integer.toString(a.getY()));
			bw.newLine();
		}
		bw.close();
	}

	public void Menu()
    {
		JMenuBar Menu = new JMenuBar();
		JMenu Fichier = new JMenu("Fichier");
		JMenu aide = new JMenu("?");
		JMenuItem Nouveau = new JMenuItem("Nouveau");
		JMenuItem Ouvrir = new JMenuItem("Ouvrir");
		JMenuItem Sauvegarder = new JMenuItem("Sauvegarder");
		JMenuItem A_propos = new JMenuItem("A propos");
		JMenuItem Quitter = new JMenuItem("Quitter");


		Fichier.add(Nouveau);
		Nouveau.addActionListener(new ActionListener()
        {
			public void actionPerformed(ActionEvent arg0)
            {
				Donnees.dessin.clear();
				new Paint();
			}
		});

		Fichier.add(Ouvrir);
		Ouvrir.addActionListener(new ActionListener()
        {
			public void actionPerformed(ActionEvent arg0)
            {
				Donnees.dessin.clear();

				try
                {
					ouvrir_f();
				} catch (NumberFormatException e)
                {
					System.out.println("non o");
					e.printStackTrace();
				} catch (IOException e)
                {
					System.out.println("non o");
					e.printStackTrace();
				}
				center.repaint();
            }
		});

		Fichier.add(Sauvegarder);
		Sauvegarder.addActionListener(new ActionListener()
        {
			public void actionPerformed(ActionEvent arg0)
            {
				try
                {
					sauvegarder_f();
				} catch (IOException e)
                {
					System.out.println("non s");
					e.printStackTrace();
				}
			}
		});

		Fichier.add(Quitter);
		Quitter.addActionListener(new ActionListener()
        {
			public void actionPerformed(ActionEvent arg0)
            {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});

		Menu.add(Fichier);
		Menu.add(aide);
		aide.add(A_propos);

		A_propos.addActionListener(new ActionListener()
        {
			public void actionPerformed(ActionEvent arg0)
            {
				JOptionPane.showMessageDialog(null,"Sarujan Rajaratnam", "Auteur", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		this.setJMenuBar(Menu);

		this.Nord();
	}

	public void Nord()
    {
		JPanel top = new JPanel();

		top.setLayout(new FlowLayout());
		top.add(new JLabel("Couleur : "));
		for(int i = 0 ; i < 3 ; i++)
        {
			couleur.addItem(Donnees.couleurs[i]);
		}
		top.add(couleur);

		top.add(new JLabel("Forme : "));
		for(int i = 0 ; i < 2 ; i++)
        {
			forme.addItem(Donnees.formes[i]);
		}
		top.add(forme);

		top.add(new JLabel("Taille : "));
		top.add(taille);

		top.add(crayon);
		top.add(gomme);
		top.add(dep);

		this.add(top, BorderLayout.NORTH);
	}

	public void Center()
    {
		this.add(center, BorderLayout.CENTER);
	}

	public void Sud()
    {

		panneau.add(eff);
		eff.addActionListener(new ActionListener()
        {
			public void actionPerformed(ActionEvent arg0)
            {
				Donnees.dessin.clear();
				center.repaint();
			}
		});
		panneau.add(rev);
		rev.addActionListener(new ActionListener()
        {
			public void actionPerformed(ActionEvent arg0)
            {
				Donnees.dessin.remove(Donnees.dessin.size()-1);
				center.repaint();

			}
		});
		this.add(panneau, BorderLayout.SOUTH);
	}

	public Color getColor()
    {
		Color c = Color.RED;
		if(couleur.getSelectedItem() == "bleu")
			c = Color.BLUE;
		else if(couleur.getSelectedItem() == "vert")
			c = Color.GREEN;
		return c;
	}

	public int getTaille()
    {
		int t = 50;
		if(!taille.getText().equals(""))
        {
			t = Integer.parseInt(taille.getText());
		}
		return t;
	}

	public void Mouse()
    {
		this.addMouseListener(new MouseListener()
        {

			public void mouseReleased(MouseEvent arg0)
            {
				x = 2000;
				y = 2000;
			}
			public void mousePressed(MouseEvent arg0) {}
			public void mouseExited(MouseEvent arg0) {}
			public void mouseEntered(MouseEvent arg0) {}


			public void mouseClicked(MouseEvent e)
            {

				/*	x = e.getX();
				y = e.getY();
				 */
				if(crayon.isSelected() == true && gomme.isSelected() == true )
                {
					JOptionPane.showMessageDialog(null,"Crayon et gomme sont cliqué", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
				if(crayon.isSelected() == true )
                {
					Dessin a = new Dessin(getTaille(),  forme.getSelectedItem().toString(), getColor(), e.getX(), e.getY());
					Donnees.dessin.add(a);
					//System.out.println(a);
					center.repaint();
				}
				if(gomme.isSelected() == true )
                {
					Dessin a = new Dessin(getTaille(),  forme.getSelectedItem().toString(), Color.WHITE, e.getX(), e.getY());
					Donnees.dessin.add(a);
					center.repaint();
				}
			}
		});



		this.addMouseMotionListener(new MouseMotionListener()
        {
			public void mouseMoved(MouseEvent arg0) {}

			public void mouseDragged(MouseEvent arg0)
            {
				x = arg0.getX();
				y = arg0.getY();
				if(dep.isSelected() == true && crayon.isSelected() == false && gomme.isSelected() == false)
                {
					//	System.out.println("x : "+ x +"  y : "+ y);
					for(int i = 0; i<Donnees.dessin.size();i++)
                    {
						if(app(x,y,i) == true)
                        {
							Dessin a = (Dessin) (Donnees.dessin.get(i));
							a.setX(arg0.getX());
							a.setY(arg0.getY());
							Donnees.dessin.set(i,a);
							center.repaint();
							x = arg0.getX();
							y = arg0.getY();
						}
					}
				}
			}
		});
	}

	public boolean app(int x, int y, int i)
    {
		boolean verif = false;
		Dessin a = (Dessin) Donnees.dessin.get(i);

		if(x>=a.getX()-(a.getTaille()/2) && x<=a.getX()+(a.getTaille()/2) && y>=a.getY()-100-(a.getTaille()/2) && y <=a.getY()+(a.getTaille()/2))
        {
			verif = true;

		}
		return verif;
	}

	public static void main(String[] args) throws IOException
    {
		new Paint();
	}
}
