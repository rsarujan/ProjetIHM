import java.awt.Color;

public class Dessin {
	
	private int taille;
	private String forme;
	private Color couleur;
	
	private int x;
	private int y;
	
	public Dessin() {
		
	}
	
	
	
	public String toString() {
		return "Dessin [taille=" + taille + ", forme=" + forme + ", couleur=" + couleur + ", x=" + x + ", y=" + y + "]";
	}



	public Dessin(int taille, String forme, Color couleur, int x, int y) {
		this.taille = taille;
		this.forme = forme;
		this.couleur = couleur;
		this.x = x;
		this.y = y;
	}



	public int getTaille() {
		return taille;
	}

	public void setTaille(int taille) {
		this.taille = taille;
	}

	public String getForme() {
		return forme;
	}

	public void setForme(String forme) {
		this.forme = forme;
	}

	public Color getCouleur() {
		return couleur;
	}

	public void setCouleur(Color couleur) {
		this.couleur = couleur;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	
	
}
