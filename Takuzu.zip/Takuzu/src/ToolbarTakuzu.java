import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ToolbarTakuzu extends JFrame
{
    private JRadioButton j1 = new JRadioButton("Four",true);
    private JRadioButton j2 = new JRadioButton("Six");
    private JRadioButton j3 = new JRadioButton("Eight");
    private JButton quitButton = new JButton("Quit");
    private JButton runButton = new JButton("Run");
    private JButton metalButton,macButton,motifButton,winButton;
    private JTable jt;
    private int dim = 4;
    JPanel tabl;
    private ButtonGroup buttonGroup= new ButtonGroup();;
    private JPanel center;
    private JTextField text;
    Takuzu.Grille g = null;
    
    public ToolbarTakuzu(String titre,int w, int h)
    {
        super(titre);
        this.setBounds(400,400,w,h);
        this.initialise();
        this.setVisible(true);
    }
    
    
    private void initialise()
    {
        this.setLayout(new BorderLayout());
        windowAdapter wa = new windowAdapter();
        this.addWindowListener(wa);
        this.add(toolbar(),BorderLayout.NORTH); //ajouter les bouton au nord
        this.add(tab(),BorderLayout.CENTER);    //ajouter le tableau au centre
        this.add(panelSud(),BorderLayout.SOUTH);//ajouter les boutons mac metal etc.. au sud
        
    }
    
    
    private JPanel toolbar()
    {
        JPanel tb = new JPanel();
        tb.setLayout(new FlowLayout(FlowLayout.CENTER));

        quitListener qL = new quitListener();       //pour quitListener
        dimListener prL = new dimListener();        //pour dimListener
        printListener printL = new printListener(); //pour printListener
        
        runButton.addActionListener(printL);        //runButton listener
        j2.addActionListener(prL);           //6button listener
        j1.addActionListener(prL);          //4button listener
        j3.addActionListener(prL);         //8button listener
        
        quitButton.addActionListener(qL);           //quitListener
        
        
        tb.add(j1);                         //ajouter 4button
        tb.add(j2);                          //ajouter 6Button
        tb.add(j3);                        //ajouter 8Button
        
        buttonGroup.add(j1);                //choisir soit 4,6,8Button
        buttonGroup.add(j2);
        buttonGroup.add(j3);
        
        tb.add(runButton);
        tb.add(quitButton);
        
        return tb;
    }
    
    
    private JPanel tab()                    //aficher le tableau au centre
    {
        tabl = new JPanel();
        jt = new JTable(dim,dim);
        tabl.add(jt);
        
        return tabl;
        
    }
    
    
    private JPanel panelSud()               //afficher les bouton mac,Motif, Metal, windows au PanelSud
    {
        JPanel pS = new JPanel();
        macButton = new JButton("Mac");
        motifButton = new JButton("Motif");
        metalButton = new JButton("Metal");
        winButton = new JButton("Windows");
        
        pS.add(macButton);              //ajouter macButton
        pS.add(metalButton);            //ajouter metalButton
        pS.add(motifButton);            //ajouter motifButton
        pS.add(winButton);              //ajouter winButton
        
        return pS;
    }

    class quitListener implements ActionListener
    {
        public void actionPerformed(ActionEvent c)
        {
            System.exit(0);         //fermer avec le boutton quit
        }
    }
    
    class dimListener implements ActionListener
    {
            public void actionPerformed(ActionEvent e)  //changer la taille du tableau en cliquant 4, 6, 8
            {
                String s = e.getActionCommand();
                if(s.equals("Four"))
                    dim = 4;
                else if (s.equals("Six"))
                    dim = 6;
                else
                    dim = 8;
            }
    }
    
    
    class printListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if(j1.isEnabled())
            {
               tabl.remove(jt);
               jt = new JTable(dim,dim);
               tabl.add(jt);
               jt.setVisible(true);
               revalidate();
               repaint();
            }
        }
    }
    
    
    class windowAdapter extends WindowAdapter
            {
                public void windowActivated(WindowEvent e)
                {
                    repaint();
                }
            }

    public static void main(String args[])
        {
            ToolbarTakuzu tf2 = new ToolbarTakuzu("Takuzu Game (Swing)",500,500);
        }
}

